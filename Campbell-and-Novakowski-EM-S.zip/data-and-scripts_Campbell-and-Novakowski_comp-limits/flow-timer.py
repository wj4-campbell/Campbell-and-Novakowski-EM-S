# author: wesley campbell
# date created: 2018

import os
import sys
import time

file_path = sys.argv[1]
modelName = sys.argv[2]

flowDone = file_path + '\\' + modelName + 'o.v_well.0001'

flowStart = time.time()
print('Timing flow solution...')
while os.path.isfile(flowDone) == False:

    continue

flowEnd = time.time()
flowTime = flowEnd - flowStart
print('Flow solution time (s):', flowTime)

recordFile = open('_flowTime_seconds.txt', 'w')
recordFile.write(str(flowTime))
recordFile.close()
