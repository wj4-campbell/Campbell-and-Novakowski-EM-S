# author: wesley campbell
# date created: 2018

import os
import sys
import time

file_path = sys.argv[1]
modelName = sys.argv[2]

grokDone = file_path + '\\' + modelName + 'o.species'

# Time the various stages of the HGS model
grokStart = time.time()
print('Timing grid generation...')

while os.path.isfile(grokDone) == False:

    continue

grokEnd = time.time()
grokTime = grokEnd - grokStart
print('Grid generation time (s):', grokTime)

# Write these to a file
recordFile = open('_gridgenTime_seconds.txt', 'w')
recordFile.write(str(grokTime))
recordFile.close()
