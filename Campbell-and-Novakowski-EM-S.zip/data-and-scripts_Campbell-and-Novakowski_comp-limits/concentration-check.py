#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Created: November 17, 2017 by Wesley Campbell

import sys
model = sys.argv[1]

def getConcentration(modelname, Co=5e-6):    
    """Open and read the observation point file from HydroGeoSphere.
    Return the decimal value of normalized concentration, relative to the
    initial concentration"""
    
    # Open and read the observation point data file
    infile = open(modelname + 'o.observation_well_conc.obswell.Species001.dat', 'r')
    readfile = infile.readlines()
    
    # Extract the most recently written concentration value
    Values = readfile[-1].split()
    C = float(Values[1])
    C_norm = C/Co
    
    # Decide if the simulation has proceeded far enough
    if C_norm < 0.9:
        Proceed = 'YES'
    else:
        Proceed = 'NO'
    infile.close()
    
    print(Proceed)
    return

getConcentration(modelname=model)
